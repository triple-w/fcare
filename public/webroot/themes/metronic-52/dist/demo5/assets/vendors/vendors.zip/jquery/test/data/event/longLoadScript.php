<?php
sleep((int)$_GET['sleep']);
header('Content-type: text/javascript');
?>